// Интеграция с платформой вынесена из игровой логики, чтобы игра продолжала
// работать при обычном локальном запуске, когда /sdk.js недоступен.
(function (global) {
  'use strict';

  var STORE_KEY = 'gamilton-snake-v1';
  var CLOUD_KEY = 'gamiltonSnakeProgress';
  var CLOUD_SAVE_DELAY = 1200;

  var ysdk = null;
  var player = null;
  var initPromise = null;
  var readySent = false;
  var gameplayRequested = false;
  var gameplayMarked = false;
  var platformPaused = false;
  var gameplayWasMarkedAtPlatformPause = false;
  var adInProgress = false;
  var cloudTimer = 0;
  var pendingCloudData = null;
  var cloudChain = Promise.resolve();
  var pauseReasons = {};
  var muteReasons = {};
  var mutedMedia = [];
  var hooks = {
    pause: function () {},
    resume: function () {},
    mute: function () {},
    unmute: function () {}
  };

  var environment = {
    language: 'ru',
    browserLanguage: (navigator.language || 'ru').slice(0, 2).toLowerCase(),
    deviceType: /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent) ? 'mobile' : 'desktop',
    appId: '',
    payload: '',
    sdkAvailable: false
  };

  function cloneData(data) {
    try { return JSON.parse(JSON.stringify(data)); }
    catch (e) { return {}; }
  }

  function hasData(data) {
    return !!data && typeof data === 'object' && Object.keys(data).length > 0;
  }

  function readLocal() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      return raw ? (JSON.parse(raw) || {}) : {};
    } catch (e) { return {}; }
  }

  function writeLocal(data) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(data)); }
    catch (e) { /* localStorage может быть недоступен в приватном режиме */ }
  }

  function collectEnvironment() {
    var sdkEnvironment = ysdk && ysdk.environment ? ysdk.environment : {};
    var i18n = sdkEnvironment.i18n || {};
    var browser = sdkEnvironment.browser || {};
    var app = sdkEnvironment.app || {};
    var device = ysdk ? ysdk.deviceInfo : null;

    // В разных выпусках SDK deviceInfo встречается как объект и как функция.
    if (typeof device === 'function') {
      try { device = device.call(ysdk); } catch (e) { device = null; }
    }

    environment.language = String(i18n.lang || 'ru').slice(0, 2).toLowerCase();
    environment.browserLanguage = String(browser.lang || navigator.language || 'ru')
      .slice(0, 2).toLowerCase();
    environment.deviceType = device && device.type ? device.type : environment.deviceType;
    environment.appId = app.id || '';
    environment.payload = sdkEnvironment.payload || '';
    environment.sdkAvailable = true;

    document.documentElement.setAttribute('data-yandex-lang', environment.language);
    document.documentElement.setAttribute('data-device', environment.deviceType);
  }

  function setPauseReason(reason, paused) {
    var wasPaused = Object.keys(pauseReasons).length > 0;
    if (paused) pauseReasons[reason] = true;
    else delete pauseReasons[reason];
    var isPaused = Object.keys(pauseReasons).length > 0;
    if (!wasPaused && isPaused) hooks.pause(reason);
    if (wasPaused && !isPaused) hooks.resume(reason);
  }

  function applyMediaMute() {
    mutedMedia = [];
    var media = document.querySelectorAll('audio, video');
    for (var i = 0; i < media.length; i++) {
      mutedMedia.push({ element: media[i], muted: media[i].muted });
      media[i].muted = true;
    }
    hooks.mute();
  }

  function restoreMediaMute() {
    for (var i = 0; i < mutedMedia.length; i++) {
      mutedMedia[i].element.muted = mutedMedia[i].muted;
    }
    mutedMedia = [];
    hooks.unmute();
  }

  function setMuteReason(reason, muted) {
    var wasMuted = Object.keys(muteReasons).length > 0;
    if (muted) muteReasons[reason] = true;
    else delete muteReasons[reason];
    var isMuted = Object.keys(muteReasons).length > 0;
    if (!wasMuted && isMuted) applyMediaMute();
    if (wasMuted && !isMuted) restoreMediaMute();
  }

  function onPlatformPause() {
    platformPaused = true;
    gameplayWasMarkedAtPlatformPause = gameplayMarked;
    gameplayMarked = false;
    setPauseReason('platform', true);
    setMuteReason('platform', true);
  }

  function onPlatformResume() {
    platformPaused = false;
    // При обычной системной паузе SDK уже восстановил Gameplay API. Фиксируем
    // это до вызова игрового resume-hook, чтобы не отправить второй start().
    if (gameplayRequested && gameplayWasMarkedAtPlatformPause) gameplayMarked = true;
    setMuteReason('platform', false);
    setPauseReason('platform', false);
    // Если игровой экран открылся уже во время рекламы, запускаем его явно.
    if (gameplayRequested && !gameplayMarked) startGameplay();
    gameplayWasMarkedAtPlatformPause = false;
  }

  function subscribeToPlatformEvents() {
    if (!ysdk || typeof ysdk.on !== 'function') return;
    ysdk.on('game_api_pause', onPlatformPause);
    ysdk.on('game_api_resume', onPlatformResume);
  }

  function result(initialData) {
    return {
      initialData: initialData || {},
      environment: environment,
      sdkAvailable: environment.sdkAvailable
    };
  }

  function init() {
    if (initPromise) return initPromise;
    var localData = readLocal();

    if (!global.YaGames || typeof global.YaGames.init !== 'function') {
      initPromise = Promise.resolve(result(localData));
      return initPromise;
    }

    initPromise = global.YaGames.init().then(function (instance) {
      ysdk = instance;
      collectEnvironment();
      subscribeToPlatformEvents();
      return ysdk.getPlayer();
    }).then(function (sdkPlayer) {
      player = sdkPlayer;
      // Облако всегда проверяется первым. Локальные данные используются только
      // при пустом ответе или ошибке облачного запроса.
      return player.getData([CLOUD_KEY]).then(function (cloud) {
        var cloudData = cloud && cloud[CLOUD_KEY];
        if (hasData(cloudData)) {
          writeLocal(cloudData);
          return result(cloudData);
        }
        if (hasData(localData)) saveProgress(localData, true);
        return result(localData);
      });
    }).catch(function (error) {
      console.warn('Яндекс Игры: облачные данные недоступны, используется localStorage.', error);
      return result(localData);
    });

    return initPromise;
  }

  function sendCloudData(data, flush) {
    if (!player || !data) return Promise.resolve(false);
    var payload = {};
    payload[CLOUD_KEY] = cloneData(data);
    cloudChain = cloudChain.catch(function () {}).then(function () {
      return player.setData(payload, !!flush);
    }).then(function () {
      return true;
    }).catch(function (error) {
      pendingCloudData = cloneData(data);
      console.warn('Яндекс Игры: не удалось сохранить прогресс в облаке.', error);
      return false;
    });
    return cloudChain;
  }

  function saveProgress(data, flush) {
    pendingCloudData = cloneData(data);
    if (!player) return Promise.resolve(false);

    if (cloudTimer) {
      clearTimeout(cloudTimer);
      cloudTimer = 0;
    }
    if (flush) {
      var immediate = pendingCloudData;
      pendingCloudData = null;
      return sendCloudData(immediate, true);
    }

    cloudTimer = setTimeout(function () {
      cloudTimer = 0;
      var queued = pendingCloudData;
      pendingCloudData = null;
      sendCloudData(queued, false);
    }, CLOUD_SAVE_DELAY);
    return Promise.resolve(true);
  }

  function gameReady() {
    if (readySent || !ysdk) return;
    readySent = true;
    if (ysdk.features && ysdk.features.LoadingAPI &&
        typeof ysdk.features.LoadingAPI.ready === 'function') {
      ysdk.features.LoadingAPI.ready();
    }
  }

  function startGameplay() {
    gameplayRequested = true;
    if (!ysdk || platformPaused || gameplayMarked) return;
    if (ysdk.features && ysdk.features.GameplayAPI &&
        typeof ysdk.features.GameplayAPI.start === 'function') {
      ysdk.features.GameplayAPI.start();
      gameplayMarked = true;
    }
  }

  function stopGameplay() {
    gameplayRequested = false;
    if (!ysdk || !gameplayMarked) return;
    if (ysdk.features && ysdk.features.GameplayAPI &&
        typeof ysdk.features.GameplayAPI.stop === 'function') {
      ysdk.features.GameplayAPI.stop();
    }
    gameplayMarked = false;
  }

  function showAd(method, callbacks) {
    callbacks = callbacks || {};
    if (!ysdk || !ysdk.adv || typeof ysdk.adv[method] !== 'function' || adInProgress) {
      return false;
    }

    var resumeGameplayAfterAd = gameplayRequested;
    var finished = false;
    adInProgress = true;
    stopGameplay();
    setPauseReason('advertising', true);
    setMuteReason('advertising', true);

    function finish(wasShown, error) {
      if (finished) return;
      finished = true;
      adInProgress = false;
      if (error) {
        console.error('Яндекс Игры: ошибка показа рекламы.', error);
        try { if (callbacks.onError) callbacks.onError(error); }
        catch (callbackError) { console.error(callbackError); }
      }
      setMuteReason('advertising', false);
      setPauseReason('advertising', false);
      try { if (callbacks.onClose) callbacks.onClose(!!wasShown); }
      catch (callbackError) { console.error(callbackError); }
      if (resumeGameplayAfterAd) startGameplay();
    }

    var sdkCallbacks = {
      onOpen: function () {
        if (callbacks.onOpen) callbacks.onOpen();
      },
      onClose: function (wasShown) { finish(wasShown, null); },
      onError: function (error) { finish(false, error); }
    };
    if (method === 'showRewardedVideo') {
      sdkCallbacks.onRewarded = function () {
        if (callbacks.onRewarded) callbacks.onRewarded();
      };
    }

    try {
      ysdk.adv[method]({ callbacks: sdkCallbacks });
    } catch (error) {
      finish(false, error);
    }
    return true;
  }

  function registerLifecycleHooks(nextHooks) {
    nextHooks = nextHooks || {};
    ['pause', 'resume', 'mute', 'unmute'].forEach(function (name) {
      if (typeof nextHooks[name] === 'function') hooks[name] = nextHooks[name];
    });
    if (Object.keys(pauseReasons).length) hooks.pause('platform');
    if (Object.keys(muteReasons).length) hooks.mute();
  }

  // Дополнительная страховка для локального запуска и браузеров, где событие
  // платформы приходит с задержкой.
  document.addEventListener('visibilitychange', function () {
    var hidden = document.visibilityState === 'hidden';
    setPauseReason('visibility', hidden);
    setMuteReason('visibility', hidden);
  });

  global.YandexGames = {
    init: init,
    gameReady: gameReady,
    startGameplay: startGameplay,
    stopGameplay: stopGameplay,
    saveProgress: saveProgress,
    showFullscreenAd: function (callbacks) { return showAd('showFullscreenAdv', callbacks); },
    showRewardedAd: function (callbacks) { return showAd('showRewardedVideo', callbacks); },
    canShowAds: function () {
      return !!(ysdk && ysdk.adv && typeof ysdk.adv.showRewardedVideo === 'function');
    },
    registerLifecycleHooks: registerLifecycleHooks,
    environment: environment
  };
})(window);
